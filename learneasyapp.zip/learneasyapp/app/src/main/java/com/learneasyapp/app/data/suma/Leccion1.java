package com.learneasyapp.app.data.suma;

import com.learneasyapp.app.objetos.Lecciones;
import com.learneasyapp.app.objetos.Pregunta;

public class Leccion1 {

    public static Lecciones get(){
        Lecciones leccion = new Lecciones();
        leccion.nombre = "Nivel 1: Sumas basicas";
        leccion.descripcion = "Este modulo comprende sumas de 1 cifra que no tienen como resultado mas de 10, ideal para practicar a sumar y contar de 1 a 9.";
        leccion.url_video = "https://www.youtube.com/watch?v=b8dW28zdg_U";
        // test
        // pregunta 1
        Pregunta pregunta = new Pregunta();
        pregunta.enunciado = new String[]{"1", "+", "1"};
        pregunta.respuestaCorrecta = "2";
        pregunta.respuestasOtras = new String[]{"4", "6", "9"};
        leccion.testPrueba.add(pregunta);
        //pregunta 2
        pregunta = new Pregunta();
        pregunta.enunciado = new String[]{"1", "+", "2"};
        pregunta.respuestaCorrecta = "3";
        pregunta.respuestasOtras = new String[]{"2", "1", "4"};

        // Leccion 2
        leccion = new Lecciones();
        leccion.nombre = "Nivel 1: Sumas basicas";
        leccion.descripcion = "Este modulo comprende sumas de 1 cifra que no tienen como resultado mas de 10, ideal para practicar a sumar y contar de 1 a 9.";
        leccion.url_video = "https://www.youtube.com/watch?v=b8dW28zdg_U";
        // test
        leccion.testPrueba.add(pregunta);
        pregunta = new Pregunta();
        pregunta.enunciado = new String[]{"1", "+", "7"};
        pregunta.respuestaCorrecta = "8";
        pregunta.respuestasOtras = new String[]{"4", "6", "9"};
        leccion.testPrueba.add(pregunta);
        return leccion;
    }
}
