package com.learneasyapp.app;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.learneasyapp.app.database.PersistenciaLocal;
import com.learneasyapp.app.objetos.Lecciones;

public class LeccionActivity extends AppCompatActivity {
    String nombre_modulo;
    Lecciones leccion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leccion);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle params = getIntent().getExtras();
        nombre_modulo = params.getString("modulo");
        leccion = (Lecciones) params.get("leccion");
        new CargarLeccion().execute("");
        actualizarPuntuacion();

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        actualizarPuntuacion();
    }

    @Override
    protected void onResume() {
        super.onResume();
        actualizarPuntuacion();
    }

    public void actualizarPuntuacion(){
        new Thread(()->{
            runOnUiThread(()->{
                int puntajePractica = PersistenciaLocal.getPuntajePractica(getApplicationContext(),nombre_modulo, leccion.nombre);
                int puntajeExamen = PersistenciaLocal.getPuntajeExamen(getApplicationContext(), nombre_modulo, leccion.nombre);
                ((TextView)findViewById(R.id.puntaje_practica))
                        .setText(String.valueOf(puntajePractica));
                ((TextView)findViewById(R.id.puntaje_mayor))
                        .setText(String.valueOf(puntajeExamen));
            });
        }).start();
    }

    class CargarLeccion extends AsyncTask<String, Integer, Boolean>{

        @Override
        protected Boolean doInBackground(String... strings) {

            runOnUiThread(()->{

                ((TextView)findViewById(R.id.titulo))
                        .setText(leccion.nombre);

                ((TextView)findViewById(R.id.contenido))
                        .setText(leccion.descripcion);

                (findViewById(R.id.video)).setOnClickListener((View view)->{
                    Uri uri = Uri.parse(leccion.url_video);
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                });
                (findViewById(R.id.volver)).setOnClickListener((View view)->{
                    onBackPressed();
                });

                findViewById(R.id.practica).setOnClickListener((View view)->{
                    Intent intent = new Intent(getApplicationContext(), CuestionarioActivity.class);
                    intent.putExtra("modulo", nombre_modulo);
                    intent.putExtra("leccion", leccion.nombre);
                    intent.putExtra("modo", "practica");
                    intent.putExtra("preguntas", leccion.testPrueba);
                    startActivity(intent);
                });

                findViewById(R.id.evaluacion).setOnClickListener((View view)->{
                    Intent intent = new Intent(getApplicationContext(), CuestionarioActivity.class);
                    intent.putExtra("modulo", nombre_modulo);
                    intent.putExtra("leccion", leccion.nombre);
                    intent.putExtra("modo", "examen");
                    intent.putExtra("preguntas", leccion.testPrueba);
                    startActivity(intent);
                });
            });

            return true;
        }
    }
}
