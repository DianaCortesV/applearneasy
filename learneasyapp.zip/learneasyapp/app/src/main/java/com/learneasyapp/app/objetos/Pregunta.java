package com.learneasyapp.app.objetos;

import java.io.Serializable;

public class Pregunta implements Serializable {

    public String[] enunciado;
    public String respuestaCorrecta;
    public String[] respuestasOtras;
}
