package com.learneasyapp.app.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQL {

    Statement st = null;

    public MySQL() {
        try {
            Connection connection = DriverManager.getConnection("learneasyapp.com", "user_db", "masterkey2019");
            this.st = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Ejecutar de tipo insert, update y delete
     * @param sql
     * @return true si hace la operación, false si falla
     */
    public boolean exec(String sql){
        try{
            st.execute(sql);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * para ejecutar queries
     * @param sql
     * @return El resultado, null si falla la consulta
     */
    public ResultSet query(String sql){
        try {
            return st.executeQuery(sql);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
