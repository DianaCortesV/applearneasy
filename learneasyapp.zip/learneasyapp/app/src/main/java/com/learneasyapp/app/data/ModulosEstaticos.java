package com.learneasyapp.app.data;

import com.learneasyapp.app.objetos.Lecciones;

import com.learneasyapp.app.objetos.Modulo;

import com.learneasyapp.app.objetos.Pregunta;


public class ModulosEstaticos {


    public static Modulo getSuma() {
        Modulo modulo = new Modulo();

        modulo.nombre = "Suma";


        // leccion 1
        Lecciones leccion1 = new Lecciones();

        leccion1.nombre = "Nivel 1: Sumas basicas";

        leccion1.descripcion = "Este modulo comprende sumas de 1 cifra que no tienen como resultado mas de 10, ideal para practicar a sumar y contar de 1 a 9.";

        leccion1.url_video = "https://www.youtube.com/watch?v=b8dW28zdg_U";


        // test prueba


        Pregunta pregunta = new Pregunta();

        pregunta.enunciado = "1 + 1  = ?";

        pregunta.respuestaCorrecta = "2";

        pregunta.respuestasOtras = new String[]{"3", "1", "4"};

        leccion1.testPrueba.add(pregunta);


        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 2  = ?";

        pregunta.respuestaCorrecta = "3";

        pregunta.respuestasOtras = new String[]{"4", "5", "2"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 3  = ?";

        pregunta.respuestaCorrecta = "4";

        pregunta.respuestasOtras = new String[]{"2", "3", "5"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 4  = ?";

        pregunta.respuestaCorrecta = "5";

        pregunta.respuestasOtras = new String[]{"3", "4", "2"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 5  = ?";

        pregunta.respuestaCorrecta = "6";

        pregunta.respuestasOtras = new String[]{"4", "5", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 6  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"6", "5", "8"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 7  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"6", "5", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 8  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"6", "7", "8"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 1  = ?";

        pregunta.respuestaCorrecta = "3";

        pregunta.respuestasOtras = new String[]{"4", "2", "1"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 2  = ?";

        pregunta.respuestaCorrecta = "4";

        pregunta.respuestasOtras = new String[]{"3", "2", "1"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 3  = ?";

        pregunta.respuestaCorrecta = "5";

        pregunta.respuestasOtras = new String[]{"4", "2", "3"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 4  = ?";

        pregunta.respuestaCorrecta = "6";

        pregunta.respuestasOtras = new String[]{"4", "5", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 5  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"5", "6", "8"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 6  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"5", "6", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 7  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"8", "6", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 1  = ?";

        pregunta.respuestaCorrecta = "4";

        pregunta.respuestasOtras = new String[]{"5", "6", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 2  = ?";

        pregunta.respuestaCorrecta = "5";

        pregunta.respuestasOtras = new String[]{"4", "6", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 3  = ?";

        pregunta.respuestaCorrecta = "6";

        pregunta.respuestasOtras = new String[]{"4", "5", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 4  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"4", "6", "5"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 5  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"9", "6", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 6  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"8", "6", "7"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 1  = ?";

        pregunta.respuestaCorrecta = "5";

        pregunta.respuestasOtras = new String[]{"6", "7", "8"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 2  = ?";

        pregunta.respuestaCorrecta = "6";

        pregunta.respuestasOtras = new String[]{"5", "7", "8"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 3  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"5", "6", "8"};

        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 4  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"6", "7", "9"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 5  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"6", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "5 + 1  = ?";

        pregunta.respuestaCorrecta = "6";

        pregunta.respuestasOtras = new String[]{"5", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "5 + 2  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"6", "9", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "5 + 3  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"6", "9", "7"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "5 + 4  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"6", "8", "7"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "6 + 1  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"6", "8", "5"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "6 + 2  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"6", "7", "5"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "6 + 3  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"6", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "7 + 1  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"6", "7", "9"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "7 + 2  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"6", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "8 + 1  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"6", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 9  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 8  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 7  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 6  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "5 + 5  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "6 + 4  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "7 + 3  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "8 + 2  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "9 + 1  = ?";

        pregunta.respuestaCorrecta = "10";

        pregunta.respuestasOtras = new String[]{"9", "7", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "1 + 0  = ?";

        pregunta.respuestaCorrecta = "1";

        pregunta.respuestasOtras = new String[]{"2", "3", "4"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "2 + 0  = ?";

        pregunta.respuestaCorrecta = "2";

        pregunta.respuestasOtras = new String[]{"1", "3", "4"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "3 + 0  = ?";

        pregunta.respuestaCorrecta = "3";

        pregunta.respuestasOtras = new String[]{"2", "1", "4"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "4 + 0  = ?";

        pregunta.respuestaCorrecta = "4";

        pregunta.respuestasOtras = new String[]{"2", "3", "5"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "5 + 0  = ?";

        pregunta.respuestaCorrecta = "5";

        pregunta.respuestasOtras = new String[]{"2", "3", "4"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "6 + 0  = ?";

        pregunta.respuestaCorrecta = "6";

        pregunta.respuestasOtras = new String[]{"5", "3", "4"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "7 + 0  = ?";

        pregunta.respuestaCorrecta = "7";

        pregunta.respuestasOtras = new String[]{"5", "6", "8"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "8 + 0  = ?";

        pregunta.respuestaCorrecta = "8";

        pregunta.respuestasOtras = new String[]{"9", "7", "6"};
        leccion1.testPrueba.add(pregunta);
        pregunta = new Pregunta();


        pregunta.enunciado = "9 + 0  = ?";

        pregunta.respuestaCorrecta = "9";

        pregunta.respuestasOtras = new String[]{"8", "7", "6"};

        leccion1.testPrueba.add(pregunta);
        modulo.lecciones.add(leccion1);

        return modulo;
    }

}
