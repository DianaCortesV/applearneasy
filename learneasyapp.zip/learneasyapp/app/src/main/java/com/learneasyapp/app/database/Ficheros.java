package com.learneasyapp.app.database;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by FabioE on 10/11/15.
 */
public class Ficheros {

    private static String _CARPETA_INTERNA = "/Android/data/la.isof.ventasmovil/";

    public static boolean Escribir_finchero(Context context, String nombre_archivo, Object object){
        try {
            FileOutputStream fos = context.openFileOutput(nombre_archivo, Context.MODE_PRIVATE);
            ObjectOutputStream salida = new ObjectOutputStream(fos);
            salida.reset();
            salida.writeObject(object);
            Log.i("MEMORY","Objeto salvado "+nombre_archivo);
            salida.close();
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    public static Object Leer_fichero(Context context, String nombre_archivo){
        Object object = null;
        try{
            FileInputStream fis = context.openFileInput(nombre_archivo);
            ObjectInputStream entrada=new ObjectInputStream(fis);
            object= entrada.readObject();
            Log.i("MEMORY","Objeto cargando ");
            entrada.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return object;
    }


    public static boolean Guardar_Imagen(Context context, String nombre_archivo, Bitmap bitmap){
        try{
            FileOutputStream outStream;
            File sdCardDirectory = context.getFilesDir();
            File image = new File(sdCardDirectory, nombre_archivo+".png");
            outStream = new FileOutputStream(image);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            /* 100 to keep full quality of the image */
            outStream.flush();
            outStream.close();
            Log.i("Imagen guardada","En la ruta :"+image.getAbsolutePath());
        }catch(Exception e){
            Log.w("Error","Error al guardar imagen. "+e.getLocalizedMessage());
            return false;
        }
        return true;
    }

    public static boolean Guardar_Imagen_Ext(Context context, String nombre_archivo, Bitmap bitmap){
        try{
            FileOutputStream outStream;
            File sdCardDirectory = context.getExternalFilesDir(null);
            File image = new File(sdCardDirectory, nombre_archivo+".png");
            outStream = new FileOutputStream(image);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            /* 100 to keep full quality of the image */
            outStream.flush();
            outStream.close();
            Log.i("Imagen guardada","En la ruta :"+image.getAbsolutePath());
        }catch(Exception e){
            Log.w("Error","Error al guardar imagen. "+e.getLocalizedMessage());
            return false;
        }
        return true;
    }

    public static String getCarpetaAplicacion(Context context){
        File sdCardDirectory = context.getFilesDir();
        return sdCardDirectory.toString();
    }

    public static Bitmap getBitmapFromURL(String src) {
        try {
            Log.e("src",src);
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            Log.e("Bitmap","returned");
            return myBitmap;
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("Exception",e.getMessage());
            return null;
        }
    }


}
