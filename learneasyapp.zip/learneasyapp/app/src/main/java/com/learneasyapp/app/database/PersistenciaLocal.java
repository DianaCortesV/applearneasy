package com.learneasyapp.app.database;

import android.content.Context;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PersistenciaLocal {

    public static void actualizaPuntajePractica(Context context, String modulo, String leccion, int puntaje){
        Object puntajeAnterior = Ficheros.Leer_fichero(context, "max_practica");
        String nombre = getMd5(modulo, leccion, "max_practica");
        if (puntajeAnterior == null){
            Ficheros.Escribir_finchero(context, nombre, puntaje);
        }
        else if(((Integer)puntajeAnterior) < puntaje){
            Ficheros.Escribir_finchero(context, nombre, puntaje);
        }
    }

    public static int getPuntajePractica(Context context, String modulo, String leccion){
        String nombre = getMd5(modulo, leccion, "max_practica");
        Object item;
        if( (item = Ficheros.Leer_fichero(context, nombre))==null){
            return 0;
        }else {
           return new Integer(item.toString());
        }
    }

    public static void actualizaPuntajeExamen(Context context, String modulo, String leccion,  int puntaje){
        String nombre = getMd5(modulo, leccion, "max_examen");
        Object puntajeAnterior = Ficheros.Leer_fichero(context, nombre);
        if (puntajeAnterior == null){
            Ficheros.Escribir_finchero(context, nombre, puntaje);
        }
        else if(((Integer)puntajeAnterior) < puntaje){
            Ficheros.Escribir_finchero(context, nombre, puntaje);
        }
    }

    public static int getPuntajeExamen(Context context, String modulo, String leccion){
        String nombre = getMd5(modulo, leccion, "max_examen");
        Object item;
        if( (item = Ficheros.Leer_fichero(context, nombre))==null){
            return 0;
        }else {
            return new Integer(item.toString());
        }
    }

    public static String getMd5(String... input)
    {
        try {
            String text = "";
            for (String a : input){
                text+=a;
            }
            // Static getInstance method is called with hashing MD5
            MessageDigest md = MessageDigest.getInstance("MD5");

            // digest() method is called to calculate message digest
            //  of an input digest() return array of byte
            byte[] messageDigest = md.digest(text.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        }

        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}
