package com.learneasyapp.app.objetos;

import java.io.Serializable;
import java.util.ArrayList;

public class Lecciones implements Serializable {
    public String nombre;
    public String descripcion;
    public String url_video;
    public int mejorPuntajePractica = 0;
    public int getMejorPuntajeFinal = 0;

    public ArrayList<Pregunta> testPrueba = new ArrayList<>();
    public ArrayList<Pregunta> testFinal = new ArrayList<>();
}
