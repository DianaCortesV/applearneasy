package com.learneasyapp.app.data;

import com.learneasyapp.app.objetos.Modulo;

public class ModulosEstaticos {


    public static Modulo getSuma() {
        Modulo modulo = new Modulo();
        modulo.nombre = "Suma";
        modulo.lecciones.add(com.learneasyapp.app.data.suma.Leccion1.get());
        modulo.lecciones.add(com.learneasyapp.app.data.suma.Leccion2.get());
        modulo.lecciones.add(com.learneasyapp.app.data.suma.Leccion3.get());
        modulo.lecciones.add(com.learneasyapp.app.data.suma.Leccion4.get());
        modulo.lecciones.add(com.learneasyapp.app.data.suma.Leccion5.get());
        return modulo;
    }


    public static Modulo getResta() {
        Modulo modulo = new Modulo();
        modulo.nombre = "Resta";
        modulo.lecciones.add(com.learneasyapp.app.data.resta.Leccion1.get());
        modulo.lecciones.add(com.learneasyapp.app.data.resta.Leccion2.get());
        modulo.lecciones.add(com.learneasyapp.app.data.resta.Leccion3.get());
        modulo.lecciones.add(com.learneasyapp.app.data.resta.Leccion4.get());
        modulo.lecciones.add(com.learneasyapp.app.data.resta.Leccion5.get());
        return modulo;
    }

    public static Modulo getMulti() {
        Modulo modulo = new Modulo();
        modulo.nombre = "Multiplicación";
        modulo.lecciones.add(com.learneasyapp.app.data.multiplicacion.Leccion1.get());
        modulo.lecciones.add(com.learneasyapp.app.data.multiplicacion.Leccion2.get());
        modulo.lecciones.add(com.learneasyapp.app.data.multiplicacion.Leccion3.get());
        modulo.lecciones.add(com.learneasyapp.app.data.multiplicacion.Leccion4.get());
        modulo.lecciones.add(com.learneasyapp.app.data.multiplicacion.Leccion5.get());
        return modulo;
    }

    public static Modulo getDivision() {
        Modulo modulo = new Modulo();
        modulo.nombre = "División";
        modulo.lecciones.add(com.learneasyapp.app.data.division.Leccion1.get());
        modulo.lecciones.add(com.learneasyapp.app.data.division.Leccion2.get());
        modulo.lecciones.add(com.learneasyapp.app.data.division.Leccion3.get());
        modulo.lecciones.add(com.learneasyapp.app.data.division.Leccion4.get());
        modulo.lecciones.add(com.learneasyapp.app.data.division.Leccion5.get());
        return modulo;
    }
}
