package com.learneasyapp.app;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.learneasyapp.app.objetos.Lecciones;
import com.learneasyapp.app.objetos.Modulo;

public class TemasActivity extends AppCompatActivity {

    Modulo modulo;
    Button[] tema = new Button[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temas);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Bundle params = getIntent().getExtras();
        //mapeo los botones
        tema[0] = findViewById(R.id.tema_1);
        tema[1] = findViewById(R.id.tema_2);
        tema[2] = findViewById(R.id.tema_3);
        tema[3] = findViewById(R.id.tema_4);
        tema[4] = findViewById(R.id.tema_5);

        if (params.containsKey("modulo")) {
            //recuperando dato del activity padre
            modulo = (Modulo) params.get("modulo");
            getSupportActionBar().setTitle(modulo.nombre);
            //inicar carga del modulo en un hilo aparte.
            new CargarModulo().execute("");
        } else {
            //vuelvo atrás si no ecuentro modulo
            this.onBackPressed();
        }
    }


    /**
     * Clase para la carga del modulo en un hilo asincronico
     */
    class CargarModulo extends AsyncTask<String, Lecciones, Boolean> {

        ProgressDialog dialog = ProgressDialog.show(TemasActivity.this, "Cargando modulo",
                "Espere un momento...", true);

        @Override
        protected void onPreExecute() {
            getSupportActionBar().setTitle(modulo.nombre);
            super.onPreExecute();
            dialog.show();
        }

        @Override
        protected void onProgressUpdate(Lecciones... values) {

        }

        @Override
        protected Boolean doInBackground(String... strings) {
            int i = 0;
            //recorro las lecciones
            for (; i < modulo.lecciones.size(); i++) {
                // obtengo la leccion en la posición *i*
                final Lecciones leccion = modulo.lecciones.get(i);
                // modifico el texto del boton al nombre de la lección y
                // le programo la acción de enviar al detalle de la misma
                tema[i].setText(leccion.nombre);
                tema[i].setOnClickListener((View view) -> {
                    Intent intent = new Intent(getApplicationContext(), LeccionActivity.class);
                    // cargo la leccion como parametro del intento
                    intent.putExtra("modulo", modulo.nombre);
                    intent.putExtra("leccion", leccion);
                    // abro el nuevo activity para visualizar la leccion
                    startActivity(intent);
                });
            }
            for (; i < tema.length; i++){
                tema[i].setVisibility(View.INVISIBLE);
            }
            return true;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            dialog.dismiss();
        }
    }
}
