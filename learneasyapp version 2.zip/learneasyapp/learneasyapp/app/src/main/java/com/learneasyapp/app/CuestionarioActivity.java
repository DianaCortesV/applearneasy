package com.learneasyapp.app;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.learneasyapp.app.database.Ficheros;
import com.learneasyapp.app.database.PersistenciaLocal;
import com.learneasyapp.app.objetos.Pregunta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class CuestionarioActivity extends AppCompatActivity {
    String modo;
    String modulo;
    String leccion;
    ArrayList<Pregunta> preguntas;
    int respuesta_correta = 0;
    int index_ultima_pregunta = 0;
    int contador_correcto = 0;
    int contador_incorrecto = 0;
    int contador_preguntas = 0;

    TextView steeps[] = new TextView[14];

    Button[] respuestas = new Button[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuestionario);
        Bundle params = getIntent().getExtras();
        modulo = params.getString("modulo");
        leccion = params.getString("leccion");
        modo = params.getString("modo");
        respuestas[0] = findViewById(R.id.opcion1);
        respuestas[1] = findViewById(R.id.opcion2);
        respuestas[2] = findViewById(R.id.opcion3);
        respuestas[3] = findViewById(R.id.opcion4);

        steeps[0] = findViewById(R.id.step1);
        steeps[1] = findViewById(R.id.step2);
        steeps[2] = findViewById(R.id.step3);
        steeps[3] = findViewById(R.id.step4);
        steeps[4] = findViewById(R.id.step5);
        steeps[5] = findViewById(R.id.step6);
        steeps[6] = findViewById(R.id.step7);
        steeps[7] = findViewById(R.id.step8);
        steeps[8] = findViewById(R.id.step9);
        steeps[9] = findViewById(R.id.step10);
        steeps[10] = findViewById(R.id.step11);
        steeps[11] = findViewById(R.id.step12);
        steeps[12] = findViewById(R.id.step13);
        steeps[13] = findViewById(R.id.step14);

        for(TextView steep : steeps) steep.setTextColor(Color.GRAY);


        ((TextView) findViewById(R.id.subtitulo)).setText(params.getString("leccion"));
        preguntas = (ArrayList<Pregunta>) params.get("preguntas");
        findViewById(R.id.volver).setOnClickListener((View view)->{
            onBackPressed();
        });
        this.setVistaModo();
    }

    private void setVistaModo() {
        if (this.modo.equalsIgnoreCase("practica")) {
            LinearLayout layout = findViewById(R.id.layout_steeps);
            layout.setVisibility(View.INVISIBLE);
            layout.setLayoutParams(new LinearLayout.LayoutParams(0,0));

        } else {
            LinearLayout layout =  findViewById(R.id.layout_marcador);
            layout.setVisibility(View.INVISIBLE);
            layout.setLayoutParams(new LinearLayout.LayoutParams(0,0));
        }
        nextPregunta();
    }

    public void updateContador(){
        ((TextView)findViewById(R.id.correctas)).setText(String.valueOf(contador_correcto));
        ((TextView)findViewById(R.id.incorrectas)).setText(String.valueOf(contador_incorrecto));
        new Thread(()->{
            if(modo.equalsIgnoreCase("practica")){
                PersistenciaLocal.actualizaPuntajePractica(getApplicationContext(), modulo, leccion, contador_correcto);
            }else{
                PersistenciaLocal.actualizaPuntajeExamen(getApplicationContext(), modulo, leccion, contador_correcto);
            }
        }).start();
    }
    public void nextPregunta() {

        setSteeps();
        int pregunta = 0;
        while((pregunta = new Random().nextInt(preguntas.size()))==index_ultima_pregunta);
        index_ultima_pregunta = pregunta;
        Pregunta actual = preguntas.get(pregunta);
        String texto_pregunta = "";
        for(String s : actual.enunciado){
            texto_pregunta+=s;
        }
        Log.i("PREGUNTA "+pregunta, texto_pregunta);
        respuesta_correta = new Random().nextInt(4);
        // Shuffle the elements in the array
        ArrayList<String> l =  new ArrayList<>();
        l.addAll(Arrays.asList(actual.respuestasOtras));
        System.out.println(l);
        Collections.shuffle(l);
        System.out.println(l);

        ((TextView) findViewById(R.id.pregunta)).setText(texto_pregunta);
        for (int i = 0; i < 4; i++) {
            if (i == respuesta_correta) {
                respuestas[i].setText(actual.respuestaCorrecta);
                respuestas[i].setOnClickListener((View view) -> {
                    contador_correcto++;
                    updateContador();
                    nextPregunta();
                });

            } else {
                respuestas[i].setText(l.get(0));
                respuestas[i].setOnClickListener((View view) -> {
                    contador_incorrecto++;
                    updateContador();
                    nextPregunta();
                });
                l.remove(0);
            }
        }
        contador_preguntas++;
    }

    private void setSteeps() {
        if(contador_preguntas<=13){
            steeps[contador_preguntas].setText("▓");
            steeps[contador_preguntas].setTextColor(Color.BLACK);
        }else{
            updateContador();
            new AlertDialog.Builder(CuestionarioActivity.this)
                    .setTitle("PRUEBA TERMINADA")
                    .setMessage("Tu puntuación fue:\nCORRECTAS: "+contador_correcto+"\nINCORRECTAS: "+contador_incorrecto)
                    .setCancelable(false)
                    .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            onBackPressed();
                        }
                    }).show();

        }
    }
}
