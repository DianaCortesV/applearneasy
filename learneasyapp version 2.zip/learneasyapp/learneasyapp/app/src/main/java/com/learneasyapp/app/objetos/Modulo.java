package com.learneasyapp.app.objetos;

import java.io.Serializable;
import java.util.ArrayList;

public class Modulo implements Serializable {
    public String nombre;
    public ArrayList<Lecciones> lecciones = new ArrayList<>();
}
