package com.learneasyapp.app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.learneasyapp.app.data.ModulosEstaticos;

public class PrincicalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_princical);


        findViewById(R.id.btn_suma).setOnClickListener((View view)->{

            Intent intent = new Intent(getApplicationContext(), TemasActivity.class);
            intent.putExtra("modulo", ModulosEstaticos.getSuma());
            startActivity(intent);
        });

        findViewById(R.id.btn_resta).setOnClickListener((View view)->{
            Intent intent = new Intent(getApplicationContext(), TemasActivity.class);
            intent.putExtra("modulo", ModulosEstaticos.getResta());
            startActivity(intent);
        });

        findViewById(R.id.btn_multi).setOnClickListener((View view)->{
            Intent intent = new Intent(getApplicationContext(), TemasActivity.class);
            intent.putExtra("modulo", ModulosEstaticos.getMulti());
            startActivity(intent);
        });

        findViewById(R.id.btn_division).setOnClickListener((View view)->{
            Intent intent = new Intent(getApplicationContext(), TemasActivity.class);
            intent.putExtra("modulo", ModulosEstaticos.getDivision());
            startActivity(intent);
        });
    }


}
